# Tactical Field Assistant AI

## Overview
This project is a decision-support AI agent designed to assist users in analyzing real-world tactical scenarios. It evaluates risk, considers environmental conditions, and provides actionable recommendations using a reasoning-based approach.

This project was built as the Final Project for ITAI 2376.

---

## Author
Solo Project – Andre Ellis

---

## Problem
In high-pressure environments, decision-making must be fast and informed. Humans can overlook key factors under stress, leading to poor outcomes.

---

## Solution
This AI agent simulates a tactical assistant that:
- Analyzes user-provided scenarios
- Assesses risk levels
- Incorporates environmental conditions
- Provides structured recommendations

---

## Project Type
Single Agent System (ReAct-based)

---

## Architecture Overview
User Input → Agent → Reasoning (LLM) → Tool Usage → Memory Update → Response

---

## Tools & Technologies
- LangChain
- OpenAI API
- Python

---

## Installation
pip install -r requirements.txt

---

## Run
python main.py

---

## Example Usage
Input:
Enemy spotted near checkpoint

Output:
High risk detected. Recommend repositioning.

---

## Limitations
- Mock data only
- No real-time APIs

---

## Demo
(Add your demo video here)
